package com.sms.services;

import java.util.List;

import com.sms.entity.Student;

public interface StudentService {
	List<Student> getAllStudents();

	public Student saveStudent(Student student);

	public Student getStudentById(long id);
	
	public Student getStudent(Student student);
	
	public void deleteStudentById(Long id);
}
