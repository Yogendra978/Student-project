package com.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.sms.entity.Student;
import com.sms.repository.StudentRepository;

@SpringBootApplication
public class StudentManagementSystemApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementSystemApplication.class, args);
	}

	@Autowired
	private StudentRepository repository;
	
	
	@Override
	public void run(String... args) throws Exception {
//		Student s1 = new Student("yogendra","saini","yogendra978@gmail.com");
//		repository.save(s1);
//		Student s2 = new Student("bhagchand","saini","bhagchand@gmail.com");
//		repository.save(s2);
//		Student s3 = new Student("sanjay","saini","sanjay@gmail.com");
//		repository.save(s3);
		
	}

}
