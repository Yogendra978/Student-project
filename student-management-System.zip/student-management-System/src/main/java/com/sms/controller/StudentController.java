package com.sms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sms.entity.Student;
import com.sms.services.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {

	private StudentService studentService;
	
	
	
	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}



	@GetMapping("/list")
	public String listStudent(Model model) {
		model.addAttribute("students",studentService.getAllStudents());
		return "students";
	}
	
	@GetMapping("/create")
	public String newStudent(Model model) {
		Student student = new Student();
		model.addAttribute("student",student);
		return "create_student";
	}
	
	@PostMapping("/create")
	public String saveStudent(@ModelAttribute("student") Student student ,RedirectAttributes re) {
		studentService.saveStudent(student);
		re.addFlashAttribute("message", "Student Created Successfully!");
		return "redirect:/student/create";
	}
	
	@GetMapping("/edit/{id}")
	public String updateStudent(@PathVariable("id") long id,Model model) {
		model.addAttribute("student",studentService.getStudentById(id));
		return "edit_student";
	}
	
	@PostMapping("/{id}")
	public String updateStudent(@PathVariable("id") long id,@ModelAttribute("student") Student student,Model mode ,RedirectAttributes re){
		Student existStudent = studentService.getStudentById(id);
		existStudent.setId(id);
		existStudent.setFirstName(student.getFirstName());
		existStudent.setLastName(student.getLastName());
		existStudent.setEmail(student.getEmail());
		studentService.getStudent(existStudent);
		re.addFlashAttribute("message", "Student Updated Successfully!");
		return "redirect:/student/list";
	}
	
	@GetMapping("/{id}")
	public String deleteStudent(@PathVariable("id") long id ,RedirectAttributes re) {
		studentService.deleteStudentById(id);
		re.addFlashAttribute("message", "Student Deleted Successfully!");
		return "redirect:/student/list";
	}
}
